package com.zoo;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat Dracoolala = new Bat(300);
		Dracoolala.attackTown();
		Dracoolala.attackTown();
		Dracoolala.attackTown();
		Dracoolala.eatHumans();
		Dracoolala.eatHumans();
		Dracoolala.fly();
		Dracoolala.fly();
		Dracoolala.displayEnergy();

	}

}
