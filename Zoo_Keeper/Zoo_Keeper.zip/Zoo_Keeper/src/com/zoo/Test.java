package com.zoo;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla dilla = new Gorilla(100);
		dilla.throwSomething();
		dilla.throwSomething();
		dilla.throwSomething();
		dilla.eatBananas();
		dilla.eatBananas();
		dilla.climb();
		dilla.displayEnergy();
	}

}
